#include <stdio.h>
#include "miniz.h"

int main()
{
    mz_zip_archive archive;
    const char *zipFilename 
    = "/home/haibeo/haibeo/Linux_Course/B2/kernel_project/kernel.zip";
        // Khởi tạo đối tượng mz_zip_archive để đọc tệp ZIP
    if (!mz_zip_reader_init_file(&archive, zipFilename, 0)) {
        // In ra lỗi nếu không mở được tệp
                printf("Lỗi khi mở tệp ZIP: %s\n", zipFilename);
        printf("Mã lỗi: %d\n", mz_zip_reader_init_file(&archive, zipFilename, 0));
        //return -1;
    }
    char buf[1024];
if (mz_zip_reader_extract_file_to_heap(&archive, buf, sizeof(buf), 0)) {
    printf("Đọc tệp thành công: %s\n", buf);
} else {
    printf("Lỗi khi đọc tệp.\n");
}
    // Lấy số lượng tệp trong ZIP
    mz_uint file_count = mz_zip_reader_get_num_files(&archive);
    printf("Số tệp trong ZIP: %u\n", file_count);
    // Liệt kê các tệp trong ZIP
    for (mz_uint i = 0; i < file_count; ++i) {
        // Lấy tên tệp trong ZIP
        char filename[256];
        if (mz_zip_reader_get_filename(&archive, i, filename, sizeof(filename))) {
            printf("Tệp %d: %s\n", i + 1, filename);

            // Lấy thông tin về tệp
            mz_zip_archive_file_stat file_stat;
            if (mz_zip_reader_file_stat(&archive, i, &file_stat)) {
                printf("  Kích thước tệp: %llu byte\n", file_stat.m_uncomp_size);
                printf("  Kích thước đã nén: %llu byte\n", file_stat.m_comp_size);
                printf("  Thời gian tạo: %s", ctime(&file_stat.m_time));
            } else {
                printf("  Không thể lấy thông tin tệp.\n");
            }
        } else {
            printf("Không thể lấy tên tệp.\n");
        }
    }
    printf("Đã mở tệp ZIP thành công: %s\n", zipFilename);
}